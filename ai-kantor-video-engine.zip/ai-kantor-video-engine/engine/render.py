import argparse, json, shutil, subprocess, tempfile
from pathlib import Path
from urllib.parse import urlparse
import requests

ROOT = Path(__file__).resolve().parents[1]
W, H, FPS = 1080, 1920, 30

def run(cmd):
    p = subprocess.run(cmd, text=True, capture_output=True)
    if p.returncode:
        raise RuntimeError(p.stderr[-6000:])

def media_path(src, temp, n):
    u = urlparse(src)
    if u.scheme in ("http", "https"):
        ext = Path(u.path).suffix or ".media"
        target = temp / f"media_{n}{ext}"
        with requests.get(src, stream=True, timeout=(20, 180)) as r:
            r.raise_for_status()
            with target.open("wb") as f:
                for chunk in r.iter_content(1024 * 1024):
                    if chunk: f.write(chunk)
        return target
    p = (ROOT / src).resolve()
    if not p.is_file(): raise FileNotFoundError(f"Media tidak ditemukan: {src}")
    return p

def duration(path):
    p = subprocess.run(["ffprobe","-v","error","-show_entries","format=duration",
        "-of","default=noprint_wrappers=1:nokey=1",str(path)],
        capture_output=True,text=True,check=True)
    return float(p.stdout.strip())

def esc(p):
    return str(p.resolve()).replace("\\","\\\\").replace(":","\\:").replace("'","\\'").replace(",","\\,")

def render(jobfile, output):
    job = json.loads(Path(jobfile).read_text(encoding="utf-8"))
    scenes = job.get("scenes", [])
    if not scenes: raise ValueError("Job harus memiliki minimal satu scene.")
    output = Path(output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory() as td:
        tmp = Path(td)
        segments = []
        for i, scene in enumerate(scenes, 1):
            src = media_path(scene["source"], tmp, i)
            image = src.suffix.lower() in {".jpg",".jpeg",".png",".webp",".bmp"}
            seconds = float(scene.get("duration", 0))
            if image and seconds <= 0: raise ValueError(f"Scene gambar {i} wajib memiliki duration.")
            if not image and seconds <= 0: seconds = duration(src)
            seg = tmp / f"seg{i:03}.mp4"
            vf = f"scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},setsar=1,format=yuv420p"
            cmd = ["ffmpeg","-y"]
            if image: cmd += ["-loop","1","-i",str(src)]
            else: cmd += ["-i",str(src)]
            cmd += ["-t",str(seconds),"-r",str(FPS),"-vf",vf,"-an",
                    "-c:v","libx264","-preset","veryfast","-crf","22",str(seg)]
            run(cmd); segments.append(seg)

        listing = tmp / "concat.txt"
        listing.write_text("".join(f"file '{p.as_posix()}'\\n" for p in segments))
        silent = tmp / "silent.mp4"
        run(["ffmpeg","-y","-f","concat","-safe","0","-i",str(listing),"-c","copy",str(silent)])

        inputs = ["-i",str(silent)]
        filters, audio_map = [], None
        if job.get("voiceover"):
            voice = media_path(job["voiceover"], tmp, 900)
            inputs += ["-i",str(voice)]
            filters.append("[1:a]volume=1.0[voice]")
            audio_map = "[voice]"
        if job.get("background_audio"):
            music = media_path(job["background_audio"], tmp, 901)
            inputs += ["-i",str(music)]
            mi = len(inputs)//2 - 1
            filters.append(f"[{mi}:a]volume=0.12[music]")
            if audio_map:
                filters.append("[voice][music]amix=inputs=2:duration=first:dropout_transition=2[aout]")
            else:
                filters.append("[music]anull[aout]")
            audio_map = "[aout]"

        cmd = ["ffmpeg","-y",*inputs]
        if job.get("subtitles"):
            sub = (ROOT / job["subtitles"]).resolve()
            if not sub.is_file(): raise FileNotFoundError(f"Subtitle tidak ditemukan: {sub}")
            style = "FontName=DejaVu Sans,FontSize=22,PrimaryColour=&H00FFFFFF,OutlineColour=&H80000000,BorderStyle=1,Outline=3,Alignment=2,MarginV=100"
            cmd += ["-vf",f"subtitles='{esc(sub)}':force_style='{style}'"]
        if filters:
            cmd += ["-filter_complex",";".join(filters),"-map","0:v:0","-map",audio_map]
        else: cmd += ["-map","0:v:0","-an"]
        cmd += ["-c:v","libx264","-preset","veryfast","-crf","22","-pix_fmt","yuv420p",
                "-r",str(FPS),"-c:a","aac","-b:a","192k","-movflags","+faststart",str(output)]
        run(cmd)

    result = {"status":"rendered","output":str(output),"width":W,"height":H,
              "aspect_ratio":"9:16","scenes":len(scenes),"duration_seconds":round(duration(output),2)}
    output.with_suffix(".json").write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2))

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--job", required=True)
    ap.add_argument("--output", default="output/video.mp4")
    a = ap.parse_args()
    if not shutil.which("ffmpeg") or not shutil.which("ffprobe"):
        raise SystemExit("FFmpeg dan FFprobe wajib tersedia.")
    render(a.job, a.output)
