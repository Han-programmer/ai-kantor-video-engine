# AI Kantor Video Engine

Worker awal untuk merender job video JSON menjadi MP4 vertikal 1080x1920 (9:16) menggunakan FFmpeg.

## Fitur
- Komposisi beberapa scene gambar/video.
- Audio narasi opsional (`voiceover`).
- Subtitle SRT opsional.
- GitHub Actions manual; hasil MP4 tersedia sebagai artifact.

## Batasan
Versi ini belum menghasilkan suara AI, belum terhubung ke Base44, dan belum memublikasikan video ke Instagram/TikTok. Audio narasi harus disediakan sebagai file audio. Integrasi publikasi akan dibuat dan diuji setelah rendering berhasil. TikTok Direct Post publik memerlukan akses API dan audit/approval yang sesuai.

## Lokal
Perlu Python 3.11+, FFmpeg, dan FFprobe.
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python -m engine.render --job jobs/example.json --output output/video.mp4
```

Path media lokal dihitung dari root repository. `source` juga dapat berupa URL HTTPS langsung. Ganti URL contoh dengan media yang Anda miliki atau berlisensi.

## GitHub Actions
Buka Actions → Render video → Run workflow. Isi `job_file` atau gunakan `jobs/example.json`. Unduh artifact `ai-kantor-rendered-video`.

Jangan simpan token/API key dalam repository. Gunakan Settings → Secrets and variables → Actions ketika integrasi publikasi ditambahkan.
