from __future__ import annotations

import argparse
import json
import mimetypes
import shutil
import subprocess
import tempfile
from pathlib import Path
from urllib.parse import urlparse

import requests

ROOT = Path(__file__).resolve().parents[1]
WIDTH, HEIGHT, FPS = 1080, 1920, 30
IMAGE_SUFFIXES = {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".gif"}


def run(command: list[str]) -> None:
    process = subprocess.run(command, text=True, capture_output=True)
    if process.returncode:
        raise RuntimeError(process.stderr[-8000:] or "Perintah gagal tanpa pesan error.")


def resolve_media(source: str, temp_dir: Path, index: int) -> tuple[Path, bool]:
    parsed = urlparse(source)
    if parsed.scheme in ("http", "https"):
        with requests.get(source, stream=True, timeout=(20, 180),
                          headers={"User-Agent": "AI-Kantor-Video-Engine/1.0"}) as response:
            response.raise_for_status()
            content_type = response.headers.get("Content-Type", "").split(";")[0].lower()
            suffix = Path(parsed.path).suffix.lower()
            if not suffix:
                suffix = mimetypes.guess_extension(content_type) or ".bin"
            target = temp_dir / f"media_{index}{suffix}"
            with target.open("wb") as output:
                for chunk in response.iter_content(chunk_size=1024 * 1024):
                    if chunk:
                        output.write(chunk)
        is_image = content_type.startswith("image/") or target.suffix.lower() in IMAGE_SUFFIXES
        return target, is_image

    path = (ROOT / source).resolve()
    if not path.is_file():
        raise FileNotFoundError(f"Media tidak ditemukan: {source}")
    is_image = path.suffix.lower() in IMAGE_SUFFIXES
    return path, is_image


def probe_duration(path: Path) -> float:
    result = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration",
         "-of", "default=noprint_wrappers=1:nokey=1", str(path)],
        capture_output=True, text=True, check=True
    )
    return float(result.stdout.strip())


def escape_filter_path(path: Path) -> str:
    value = str(path.resolve()).replace("\\", "\\\\")
    value = value.replace(":", r"\:").replace("'", r"\'").replace(",", r"\,")
    return value


def render(job_file: Path, output_file: Path) -> dict:
    job = json.loads(job_file.read_text(encoding="utf-8"))
    scenes = job.get("scenes") or []
    if not scenes:
        raise ValueError("Job harus memiliki minimal satu scene.")

    output_file.parent.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory(prefix="ai-kantor-render-") as temp:
        temp_dir = Path(temp)
        segment_files: list[Path] = []

        for index, scene in enumerate(scenes, start=1):
            if not scene.get("source"):
                raise ValueError(f"Scene {index} tidak memiliki source.")
            media, is_image = resolve_media(scene["source"], temp_dir, index)
            seconds = float(scene.get("duration") or 0)

            if is_image and seconds <= 0:
                raise ValueError(f"Scene gambar {index} wajib memiliki duration lebih dari 0.")
            if not is_image and seconds <= 0:
                seconds = probe_duration(media)
            if seconds <= 0:
                raise ValueError(f"Durasi scene {index} tidak valid.")

            segment = temp_dir / f"segment_{index:03d}.mp4"
            video_filter = (
                f"scale={WIDTH}:{HEIGHT}:force_original_aspect_ratio=increase,"
                f"crop={WIDTH}:{HEIGHT},setsar=1,fps={FPS},format=yuv420p"
            )
            command = ["ffmpeg", "-y"]
            if is_image:
                command += ["-loop", "1", "-framerate", str(FPS), "-i", str(media)]
            else:
                command += ["-i", str(media)]
            command += [
                "-t", str(seconds), "-vf", video_filter, "-an",
                "-c:v", "libx264", "-preset", "veryfast", "-crf", "22",
                "-pix_fmt", "yuv420p", str(segment)
            ]
            run(command)
            segment_files.append(segment)

        # concat demuxer membutuhkan satu nama file per baris.
        concat_file = temp_dir / "concat.txt"
        concat_file.write_text(
            "".join(f"file '{segment.as_posix()}'\n" for segment in segment_files),
            encoding="utf-8"
        )
        silent_video = temp_dir / "silent.mp4"
        run([
            "ffmpeg", "-y", "-f", "concat", "-safe", "0",
            "-i", str(concat_file), "-c", "copy", str(silent_video)
        ])

        input_args = ["-i", str(silent_video)]
        audio_filters: list[str] = []
        audio_labels: list[str] = []

        if job.get("voiceover"):
            voice_path, _ = resolve_media(job["voiceover"], temp_dir, 900)
            input_args += ["-i", str(voice_path)]
            audio_filters.append("[1:a]volume=1.0[voice]")
            audio_labels.append("[voice]")

        if job.get("background_audio"):
            music_path, _ = resolve_media(job["background_audio"], temp_dir, 901)
            music_input_index = 1 + (1 if job.get("voiceover") else 0)
            input_args += ["-i", str(music_path)]
            audio_filters.append(f"[{music_input_index}:a]volume=0.12[music]")
            audio_labels.append("[music]")

        command = ["ffmpeg", "-y", *input_args]
        subtitle_file = job.get("subtitles")
        if subtitle_file:
            subtitle_path = (ROOT / subtitle_file).resolve()
            if not subtitle_path.is_file():
                raise FileNotFoundError(f"Subtitle tidak ditemukan: {subtitle_file}")
            style = (
                "FontName=DejaVu Sans,FontSize=22,PrimaryColour=&H00FFFFFF,"
                "OutlineColour=&H80000000,BorderStyle=1,Outline=3,"
                "Shadow=1,Alignment=2,MarginV=100"
            )
            command += [
                "-vf",
                f"subtitles='{escape_filter_path(subtitle_path)}':force_style='{style}'"
            ]

        if len(audio_labels) == 2:
            audio_filters.append(
                f"{audio_labels[0]}{audio_labels[1]}"
                "amix=inputs=2:duration=first:dropout_transition=2[aout]"
            )
            audio_output = "[aout]"
        elif len(audio_labels) == 1:
            audio_output = audio_labels[0]
        else:
            audio_output = None

        if audio_filters:
            command += [
                "-filter_complex", ";".join(audio_filters),
                "-map", "0:v:0", "-map", audio_output
            ]
        else:
            command += ["-map", "0:v:0", "-an"]

        command += [
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "22",
            "-pix_fmt", "yuv420p", "-r", str(FPS),
            "-movflags", "+faststart"
        ]
        if audio_output:
            command += ["-c:a", "aac", "-b:a", "192k"]
        command.append(str(output_file))
        run(command)

    result = {
        "status": "rendered",
        "output": str(output_file),
        "width": WIDTH,
        "height": HEIGHT,
        "aspect_ratio": "9:16",
        "scenes": len(scenes),
        "duration_seconds": round(probe_duration(output_file), 2)
    }
    output_file.with_suffix(".json").write_text(
        json.dumps(result, indent=2), encoding="utf-8"
    )
    print(json.dumps(result, indent=2))
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description="Render AI Kantor vertical MP4.")
    parser.add_argument("--job", required=True, help="Path ke file JSON job.")
    parser.add_argument("--output", default="output/video.mp4", help="Path output MP4.")
    args = parser.parse_args()

    if not shutil.which("ffmpeg") or not shutil.which("ffprobe"):
        raise SystemExit("FFmpeg dan FFprobe wajib tersedia.")
    render(Path(args.job).resolve(), Path(args.output).resolve())


if __name__ == "__main__":
    main()
