# AI Kantor Video Engine

Worker awal untuk merender job JSON menjadi MP4 vertikal 1080x1920 (9:16) dengan FFmpeg.

## Fitur versi ini
- Scene gambar dan video, dengan deteksi MIME untuk URL tanpa ekstensi.
- Komposisi beberapa scene; file concat ditulis dengan newline yang benar.
- Audio narasi dan musik latar opsional.
- Subtitle SRT opsional.
- GitHub Actions manual untuk render dan mengunggah artifact.

## Batasan
Belum menghasilkan naskah atau suara AI, belum terhubung ke Base44, dan belum memublikasikan ke Instagram/TikTok. File audio/subtitle/media perlu disediakan pada job. Integrasi publikasi perlu dibuat dan diuji terpisah. TikTok Direct Post publik memerlukan akses API dan audit/approval yang sesuai.

## Menjalankan
Python 3.11+, FFmpeg, dan FFprobe diperlukan.
```bash
pip install -r requirements.txt
python -m engine.render --job jobs/example.json --output output/video.mp4
```

Path lokal dihitung dari root repository. URL media harus berupa URL unduhan langsung. Gunakan media yang dimiliki atau berlisensi.

## GitHub Actions
Buka Actions → Render video → Run workflow. Isi `job_file` atau gunakan `jobs/example.json`. Unduh artifact `ai-kantor-rendered-video`.

Jangan menyimpan token/API key di repository. Gunakan GitHub Actions Secrets untuk integrasi yang memerlukannya.
