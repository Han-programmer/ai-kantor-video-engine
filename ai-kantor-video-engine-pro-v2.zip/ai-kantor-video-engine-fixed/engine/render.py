from __future__ import annotations

import argparse
import json
import mimetypes
import shutil
import subprocess
import tempfile
from pathlib import Path
from urllib.parse import urlparse

import requests
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parents[1]
WIDTH, HEIGHT, FPS = 1080, 1920, 30
IMAGE_SUFFIXES = {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".gif"}
FONT_BOLD = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
FONT_REGULAR = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"


def run(command: list[str]) -> None:
    p = subprocess.run(command, text=True, capture_output=True)
    if p.returncode:
        raise RuntimeError(p.stderr[-10000:] or "Perintah gagal tanpa pesan error.")


def resolve_media(source: str, temp_dir: Path, index: int) -> tuple[Path, bool]:
    parsed = urlparse(source)
    if parsed.scheme in ("http", "https"):
        with requests.get(source, stream=True, timeout=(20, 180), headers={"User-Agent": "AI-Kantor-Video-Engine/2.0"}) as response:
            response.raise_for_status()
            content_type = response.headers.get("Content-Type", "").split(";")[0].lower()
            suffix = Path(parsed.path).suffix.lower() or mimetypes.guess_extension(content_type) or ".bin"
            target = temp_dir / f"media_{index}{suffix}"
            with target.open("wb") as out:
                for chunk in response.iter_content(1024 * 1024):
                    if chunk:
                        out.write(chunk)
        return target, content_type.startswith("image/") or target.suffix.lower() in IMAGE_SUFFIXES
    path = (ROOT / source).resolve()
    if not path.is_file():
        raise FileNotFoundError(f"Media tidak ditemukan: {source}")
    return path, path.suffix.lower() in IMAGE_SUFFIXES


def duration(path: Path) -> float:
    p = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", str(path)], capture_output=True, text=True, check=True)
    return float(p.stdout.strip())


def wrap_text(draw: ImageDraw.ImageDraw, text: str, font: ImageFont.FreeTypeFont, max_width: int) -> list[str]:
    lines: list[str] = []
    for paragraph in text.splitlines() or [text]:
        words = paragraph.split()
        line = ""
        for word in words:
            candidate = f"{line} {word}".strip()
            if draw.textbbox((0, 0), candidate, font=font)[2] <= max_width:
                line = candidate
            else:
                if line:
                    lines.append(line)
                line = word
        if line:
            lines.append(line)
    return lines


def make_overlay(scene: dict, path: Path) -> None:
    image = Image.new("RGBA", (WIDTH, HEIGHT), (0, 0, 0, 0))
    draw = ImageDraw.Draw(image)
    title = str(scene.get("title", "")).strip()
    body = str(scene.get("text", "")).strip()
    if title or body:
        # Gradient-like dark panel for legibility, keeping important content inside safe margins.
        panel_top = 1120 if scene.get("text_position", "bottom") == "bottom" else 250
        panel_bottom = min(HEIGHT - 150, panel_top + (560 if title and body else 380))
        draw.rounded_rectangle((64, panel_top, WIDTH - 64, panel_bottom), radius=42, fill=(5, 8, 18, 190), outline=(255, 255, 255, 55), width=2)
        y = panel_top + 48
        if title:
            font = ImageFont.truetype(FONT_BOLD, 62)
            for line in wrap_text(draw, title, font, WIDTH - 180)[:3]:
                draw.text((104, y), line, font=font, fill=(255, 255, 255, 255), stroke_width=1, stroke_fill=(0, 0, 0, 120))
                y += 82
        if body:
            y += 14
            font = ImageFont.truetype(FONT_REGULAR, 38)
            for line in wrap_text(draw, body, font, WIDTH - 180)[:5]:
                draw.text((104, y), line, font=font, fill=(238, 242, 255, 255))
                y += 54
    # Small brand mark, consistently within vertical-video safe area.
    brand = str(scene.get("brand", "AI KANTOR")).strip()
    if brand:
        font = ImageFont.truetype(FONT_BOLD, 27)
        draw.rounded_rectangle((64, 72, 310, 132), radius=24, fill=(10, 10, 18, 150))
        draw.text((88, 86), brand[:22], font=font, fill=(255, 255, 255, 240))
    image.save(path)


def generate_voiceover(text: str, voice: str, out_audio: Path, out_srt: Path) -> None:
    # Edge TTS provides Indonesian neural voices and time-aligned subtitle output.
    run(["edge-tts", "--voice", voice, "--text", text, "--write-media", str(out_audio), "--write-subtitles", str(out_srt)])


def render(job_file: Path, output_file: Path) -> dict:
    job = json.loads(job_file.read_text(encoding="utf-8"))
    scenes = job.get("scenes") or []
    if not scenes:
        raise ValueError("Job harus memiliki minimal satu scene.")
    output_file.parent.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory(prefix="ai-kantor-render-") as td:
        tmp = Path(td)
        segments: list[Path] = []
        for i, scene in enumerate(scenes, 1):
            if not scene.get("source"):
                raise ValueError(f"Scene {i} tidak memiliki source.")
            media, is_image = resolve_media(scene["source"], tmp, i)
            seconds = float(scene.get("duration") or 0)
            if is_image and seconds <= 0:
                raise ValueError(f"Scene gambar {i} wajib memiliki duration > 0.")
            if not is_image and seconds <= 0:
                seconds = duration(media)
            if seconds <= 0:
                raise ValueError(f"Durasi scene {i} tidak valid.")

            overlay = tmp / f"overlay_{i:03d}.png"
            make_overlay(scene, overlay)
            seg = tmp / f"segment_{i:03d}.mp4"
            vf = f"scale={WIDTH}:{HEIGHT}:force_original_aspect_ratio=increase,crop={WIDTH}:{HEIGHT},setsar=1,fps={FPS},format=yuv420p"
            cmd = ["ffmpeg", "-y"]
            if is_image:
                cmd += ["-loop", "1", "-framerate", str(FPS), "-i", str(media)]
            else:
                cmd += ["-i", str(media)]
            cmd += ["-loop", "1", "-i", str(overlay), "-t", str(seconds), "-filter_complex", f"[0:v]{vf}[base];[base][1:v]overlay=0:0:shortest=1,format=yuv420p[v]", "-map", "[v]", "-an", "-c:v", "libx264", "-preset", "veryfast", "-crf", "21", "-pix_fmt", "yuv420p", str(seg)]
            run(cmd)
            segments.append(seg)

        concat = tmp / "concat.txt"
        concat.write_text("".join(f"file '{p.as_posix()}'\n" for p in segments), encoding="utf-8")
        silent = tmp / "silent.mp4"
        run(["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", str(concat), "-c", "copy", str(silent)])

        voice_path: Path | None = None
        subtitle_path: Path | None = None
        if job.get("narration"):
            voice_path, subtitle_path = tmp / "voice.mp3", tmp / "voice.srt"
            generate_voiceover(str(job["narration"]), str(job.get("voice", "id-ID-ArdiNeural")), voice_path, subtitle_path)
        elif job.get("voiceover"):
            voice_path, _ = resolve_media(job["voiceover"], tmp, 900)
            if job.get("subtitles"):
                subtitle_path = (ROOT / job["subtitles"]).resolve()

        music_path: Path | None = None
        if job.get("background_audio"):
            music_path, _ = resolve_media(job["background_audio"], tmp, 901)

        inputs = ["-i", str(silent)]
        if voice_path:
            inputs += ["-i", str(voice_path)]
        if music_path:
            inputs += ["-stream_loop", "-1", "-i", str(music_path)]

        filters: list[str] = []
        labels: list[str] = []
        idx = 1
        if voice_path:
            filters.append(f"[{idx}:a]volume=1.0[voice]")
            labels.append("[voice]")
            idx += 1
        if music_path:
            filters.append(f"[{idx}:a]volume={float(job.get('music_volume', 0.12))}[music]")
            labels.append("[music]")
        if len(labels) == 2:
            filters.append("[voice][music]amix=inputs=2:duration=first:dropout_transition=2[aout]")
            audio_map = "[aout]"
        elif labels:
            audio_map = labels[0]
        else:
            audio_map = None

        cmd = ["ffmpeg", "-y", *inputs]
        if subtitle_path and subtitle_path.is_file():
            style = "FontName=DejaVu Sans,FontSize=18,PrimaryColour=&H00FFFFFF,OutlineColour=&H90000000,BorderStyle=1,Outline=3,Shadow=1,Alignment=2,MarginV=150"
            sub = str(subtitle_path).replace("\\", "\\\\").replace(":", "\\:").replace("'", "\\'").replace(",", "\\,")
            cmd += ["-vf", f"subtitles='{sub}':force_style='{style}'"]
        if filters:
            cmd += ["-filter_complex", ";".join(filters), "-map", "0:v:0", "-map", audio_map]
        else:
            cmd += ["-map", "0:v:0", "-an"]
        cmd += ["-c:v", "libx264", "-preset", "veryfast", "-crf", "21", "-pix_fmt", "yuv420p", "-r", str(FPS), "-movflags", "+faststart"]
        if audio_map:
            cmd += ["-c:a", "aac", "-b:a", "192k", "-shortest"]
        cmd.append(str(output_file))
        run(cmd)

    result = {"status": "rendered", "output": str(output_file), "width": WIDTH, "height": HEIGHT, "aspect_ratio": "9:16", "fps": FPS, "scenes": len(scenes), "audio": bool(job.get("narration") or job.get("voiceover") or job.get("background_audio")), "subtitles": bool(job.get("narration") or job.get("subtitles")), "duration_seconds": round(duration(output_file), 2)}
    output_file.with_suffix(".json").write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(result, indent=2, ensure_ascii=False))
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description="AI Kantor vertical MP4 renderer")
    parser.add_argument("--job", required=True)
    parser.add_argument("--output", default="output/video.mp4")
    args = parser.parse_args()
    if not shutil.which("ffmpeg") or not shutil.which("ffprobe"):
        raise SystemExit("FFmpeg dan FFprobe wajib tersedia.")
    render(Path(args.job).resolve(), Path(args.output).resolve())


if __name__ == "__main__":
    main()
