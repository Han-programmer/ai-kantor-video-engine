# AI Kantor Video Engine

Renderer video vertikal untuk konten sosial media. Output: MP4 H.264, 1080x1920, 30 FPS, rasio 9:16.

## Fitur
- Gabungkan beberapa scene gambar atau video.
- Potong media ke kanvas vertikal tanpa letterbox.
- Judul, teks penjelas, dan label brand per scene dengan panel kontras agar terbaca.
- Narasi Bahasa Indonesia melalui Edge TTS (`id-ID-ArdiNeural` atau `id-ID-GadisNeural`).
- Subtitle SRT otomatis dari Edge TTS.
- Audio latar opsional dengan kontrol volume.

## Menjalankan di GitHub Actions
1. Letakkan isi folder ini di root repository.
2. Jalankan workflow `Render video` dari tab Actions.
3. Unduh artifact `ai-kantor-rendered-video`.

## Job JSON
Lihat `jobs/example.json`. Setiap scene memerlukan `source` dan untuk gambar `duration`. `narration` bersifat opsional. Jika disediakan, workflow membuat audio narasi dan subtitle otomatis.

## Catatan
- Edge TTS memerlukan koneksi internet pada saat render.
- Gunakan media dan musik yang Anda miliki hak penggunaannya.
- Renderer belum memublikasikan konten ke Instagram atau TikTok; publikasi memerlukan integrasi API dan kredensial yang sah.
